﻿'Author : Kyle Roddick
'Date: 01/22/20
'Description: Allows the user to enter a series of units shipped values, then records these and when 7 days are entered it calculates
'             and displays an average.
Public Class frmAverageUnitsShipped

    Dim currentDay As Integer = 1
    Dim totalUnits As Double = 0
    Dim success As Boolean
    ''' <summary>
    ''' 'Reset variables, input and output fields so application returns to its default state
    ''' </summary>


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'This closes the form'
        Me.Close()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        'Reset the variables used to their base values
        currentDay = 1
        totalUnits = 0

        'Clearing the input and output textboxes
        txtUnitsInputed.Clear()
        txtUnitsList.Clear()
        lblAverageOutput.Text = String.Empty
        lblDay.Text = "Day " & currentDay

        'Re-enable any potentially disabled controls
        txtUnitsInputed.Enabled = True
        btnEnter.Enabled = True

        'Set focus to the default expected control
        txtUnitsInputed.Focus()




    End Sub
    ''' <summary>
    ''' Validates the users input and adds it to the list of units, increments the total and determines/outputs an average depending on the day.
    ''' </summary>

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Const DaysInWeek As Integer = 7
        Dim averageUnits As Double
        Dim currentUnits As Integer
        Dim value As Integer

        'This is to check validation for the input is a whole number between 0 and 5000
        success = Double.TryParse(txtUnitsInputed.Text, value)
        If (value > 5000.0 Or value < 0.0 Or success = False) Then 'Displays error message
            MessageBox.Show("The entered units is not a valid range. Please enter a whole number between 0 & 5000 and try again.")
            txtUnitsInputed.SelectAll()
            txtUnitsInputed.Focus()

            ' Check if the entered units value is a number
        ElseIf Integer.TryParse(value, currentUnits) Then
            'The entered units is a number!
            'Increment the day and the total units shipped
            currentDay += 1
            totalUnits += currentUnits

            txtUnitsList.Text &= currentUnits & vbCrLf

            'Clears the input box when input is entered and stored
            txtUnitsInputed.Clear()


            'Check if we have enter 7 days 


            'Check to see if 7 days of data have been entered
            If currentDay > DaysInWeek Then

                'Disable some controls
                txtUnitsInputed.Enabled = False
                btnEnter.Enabled = False

                'Calculates and displays the average units shipped in the 7 days entered
                averageUnits = totalUnits / DaysInWeek
                lblAverageOutput.Text = "Average units shipped per day: " &
                    Math.Round(averageUnits, 2)

                btnReset.Focus()


            Else

                'Check if we have enter 7 days 
                lblDay.Text = "Day " & currentDay

            End If













        End If









    End Sub
End Class
