﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShippedByEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblEmployee1AvgOutput = New System.Windows.Forms.Label()
        Me.lblEmployee2AvgOutput = New System.Windows.Forms.Label()
        Me.lblEmployee3AvgOutput = New System.Windows.Forms.Label()
        Me.txtEmployee1Units = New System.Windows.Forms.TextBox()
        Me.lblOverallAverageOutput = New System.Windows.Forms.Label()
        Me.txtEmployee2Units = New System.Windows.Forms.TextBox()
        Me.txtEmployee3Units = New System.Windows.Forms.TextBox()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblEmployee1 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.txtUnitsInput = New System.Windows.Forms.TextBox()
        Me.lblUnitsPrompt = New System.Windows.Forms.Label()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblEmployee1AvgOutput
        '
        Me.lblEmployee1AvgOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee1AvgOutput.Location = New System.Drawing.Point(28, 233)
        Me.lblEmployee1AvgOutput.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee1AvgOutput.Name = "lblEmployee1AvgOutput"
        Me.lblEmployee1AvgOutput.Size = New System.Drawing.Size(98, 19)
        Me.lblEmployee1AvgOutput.TabIndex = 5
        Me.lblEmployee1AvgOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblEmployee1AvgOutput, "Displays the calculated average units shipped for Employee 1")
        '
        'lblEmployee2AvgOutput
        '
        Me.lblEmployee2AvgOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee2AvgOutput.Location = New System.Drawing.Point(164, 233)
        Me.lblEmployee2AvgOutput.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee2AvgOutput.Name = "lblEmployee2AvgOutput"
        Me.lblEmployee2AvgOutput.Size = New System.Drawing.Size(98, 19)
        Me.lblEmployee2AvgOutput.TabIndex = 8
        Me.lblEmployee2AvgOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblEmployee2AvgOutput, "Displays the calculated average units shipped for Employee 2")
        '
        'lblEmployee3AvgOutput
        '
        Me.lblEmployee3AvgOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee3AvgOutput.Location = New System.Drawing.Point(296, 233)
        Me.lblEmployee3AvgOutput.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee3AvgOutput.Name = "lblEmployee3AvgOutput"
        Me.lblEmployee3AvgOutput.Size = New System.Drawing.Size(98, 19)
        Me.lblEmployee3AvgOutput.TabIndex = 11
        Me.lblEmployee3AvgOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblEmployee3AvgOutput, "Displays the calculated average units shipped for Employee 3")
        '
        'txtEmployee1Units
        '
        Me.txtEmployee1Units.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtEmployee1Units.Location = New System.Drawing.Point(28, 90)
        Me.txtEmployee1Units.Multiline = True
        Me.txtEmployee1Units.Name = "txtEmployee1Units"
        Me.txtEmployee1Units.ReadOnly = True
        Me.txtEmployee1Units.Size = New System.Drawing.Size(98, 140)
        Me.txtEmployee1Units.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.txtEmployee1Units, "Displays a list of entered units shipped for Employee 1")
        '
        'lblOverallAverageOutput
        '
        Me.lblOverallAverageOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOverallAverageOutput.Location = New System.Drawing.Point(28, 261)
        Me.lblOverallAverageOutput.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblOverallAverageOutput.Name = "lblOverallAverageOutput"
        Me.lblOverallAverageOutput.Size = New System.Drawing.Size(366, 26)
        Me.lblOverallAverageOutput.TabIndex = 12
        Me.lblOverallAverageOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblOverallAverageOutput, "Displays the calculated overall average units shipped of the 3 employees")
        '
        'txtEmployee2Units
        '
        Me.txtEmployee2Units.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtEmployee2Units.Location = New System.Drawing.Point(164, 90)
        Me.txtEmployee2Units.Multiline = True
        Me.txtEmployee2Units.Name = "txtEmployee2Units"
        Me.txtEmployee2Units.ReadOnly = True
        Me.txtEmployee2Units.Size = New System.Drawing.Size(98, 140)
        Me.txtEmployee2Units.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtEmployee2Units, "Displays a list of entered units shipped for Employee 2")
        '
        'txtEmployee3Units
        '
        Me.txtEmployee3Units.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtEmployee3Units.Location = New System.Drawing.Point(296, 90)
        Me.txtEmployee3Units.Multiline = True
        Me.txtEmployee3Units.Name = "txtEmployee3Units"
        Me.txtEmployee3Units.ReadOnly = True
        Me.txtEmployee3Units.Size = New System.Drawing.Size(98, 140)
        Me.txtEmployee3Units.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.txtEmployee3Units, "Displays a list of entered units shipped for Employee 3")
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(28, 312)
        Me.btnEnter.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(98, 23)
        Me.btnEnter.TabIndex = 13
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip1.SetToolTip(Me.btnEnter, "Click to enter in your units shipped")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(164, 312)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(2)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(98, 23)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.ToolTip1.SetToolTip(Me.btnReset, "Click to reset the form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(296, 312)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(98, 23)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExit, "Click to exit the application")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblEmployee1
        '
        Me.lblEmployee1.Location = New System.Drawing.Point(25, 68)
        Me.lblEmployee1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee1.Name = "lblEmployee1"
        Me.lblEmployee1.Size = New System.Drawing.Size(88, 19)
        Me.lblEmployee1.TabIndex = 3
        Me.lblEmployee1.Text = "Employee 1"
        Me.lblEmployee1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee2
        '
        Me.lblEmployee2.Location = New System.Drawing.Point(164, 68)
        Me.lblEmployee2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(85, 19)
        Me.lblEmployee2.TabIndex = 6
        Me.lblEmployee2.Text = "Employee 2"
        Me.lblEmployee2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblEmployee3
        '
        Me.lblEmployee3.Location = New System.Drawing.Point(296, 68)
        Me.lblEmployee3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(85, 19)
        Me.lblEmployee3.TabIndex = 9
        Me.lblEmployee3.Text = "Employee 3"
        Me.lblEmployee3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtUnitsInput
        '
        Me.txtUnitsInput.Location = New System.Drawing.Point(61, 37)
        Me.txtUnitsInput.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUnitsInput.Name = "txtUnitsInput"
        Me.txtUnitsInput.Size = New System.Drawing.Size(65, 20)
        Me.txtUnitsInput.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtUnitsInput, "Enter the units shipped to record")
        '
        'lblUnitsPrompt
        '
        Me.lblUnitsPrompt.Location = New System.Drawing.Point(-18, 37)
        Me.lblUnitsPrompt.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblUnitsPrompt.Name = "lblUnitsPrompt"
        Me.lblUnitsPrompt.Size = New System.Drawing.Size(75, 19)
        Me.lblUnitsPrompt.TabIndex = 1
        Me.lblUnitsPrompt.Text = "&Units:"
        Me.lblUnitsPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDay
        '
        Me.lblDay.Location = New System.Drawing.Point(11, 9)
        Me.lblDay.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(46, 19)
        Me.lblDay.TabIndex = 0
        Me.lblDay.Text = "Day 1"
        Me.lblDay.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frmAverageUnitsShippedByEmployee
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(423, 346)
        Me.Controls.Add(Me.lblDay)
        Me.Controls.Add(Me.lblUnitsPrompt)
        Me.Controls.Add(Me.txtUnitsInput)
        Me.Controls.Add(Me.lblEmployee3)
        Me.Controls.Add(Me.lblEmployee2)
        Me.Controls.Add(Me.lblEmployee1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.txtEmployee3Units)
        Me.Controls.Add(Me.txtEmployee2Units)
        Me.Controls.Add(Me.lblOverallAverageOutput)
        Me.Controls.Add(Me.txtEmployee1Units)
        Me.Controls.Add(Me.lblEmployee3AvgOutput)
        Me.Controls.Add(Me.lblEmployee2AvgOutput)
        Me.Controls.Add(Me.lblEmployee1AvgOutput)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnitsShippedByEmployee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped By Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblEmployee1AvgOutput As Label
    Friend WithEvents lblEmployee2AvgOutput As Label
    Friend WithEvents lblEmployee3AvgOutput As Label
    Friend WithEvents txtEmployee1Units As TextBox
    Friend WithEvents lblOverallAverageOutput As Label
    Friend WithEvents txtEmployee2Units As TextBox
    Friend WithEvents txtEmployee3Units As TextBox
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblEmployee1 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents txtUnitsInput As TextBox
    Friend WithEvents lblUnitsPrompt As Label
    Friend WithEvents lblDay As Label
    Friend WithEvents ToolTip1 As ToolTip
End Class
