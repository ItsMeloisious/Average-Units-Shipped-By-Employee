﻿' Project: Lab 3
' Author: Kyle Roddick
' Date: 02/25/20
' Description: Allows the user to enter a series of units shipped values for 3 employees, it records their values in a textbox for each day,
'              and when 7 days are entered it calculates and displays an average, then moves on to the next employee. 
'              Once the 3rd employee has inputed all his units shipped for the 7 days, a overall calculated avereage of the 3 employees is displayed.



Option Strict On
Public Class frmAverageUnitsShippedByEmployee

#Region "Variable Declarations"
    Dim day As Integer = 0  ' Refers to the current day being entered
    Dim employee As Integer = 0 ' Refers to the current employee being entered

    Dim employeeTotalUnitsShipped As Double
    Dim overallTotalUnitsShipped As Double

    Dim employeeAverageUnitsShipped As Double
    Dim overallAverageUnitsShipped As Double

    Dim unitsArray(2, 6) As Double    ' Array of units values

    ' Declare two arrays of controls to make later code more structured and efficient
    Dim textboxArray() As TextBox
    Dim outputLabelArray() As Label
#End Region


#Region "Event Handlers"

    Private Sub frmAverageUnitsShippedByEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Array of textboxes referring to the three large textboxes
        textboxArray = {txtEmployee1Units, txtEmployee2Units, txtEmployee3Units}

        ' Array of labels referring to the three labels with the averages
        outputLabelArray = {lblEmployee1AvgOutput, lblEmployee2AvgOutput, lblEmployee3AvgOutput}
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Closes the application
        Me.Close()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        ' Clear the textboxes for input and output
        txtUnitsInput.Clear()
        txtEmployee1Units.Clear()
        txtEmployee2Units.Clear()
        txtEmployee3Units.Clear()

        ' Clear all average output labels
        lblEmployee1AvgOutput.Text = String.Empty
        lblEmployee2AvgOutput.Text = String.Empty
        lblEmployee3AvgOutput.Text = String.Empty
        lblOverallAverageOutput.Text = String.Empty

        ' Re-enable the input controls
        txtUnitsInput.Enabled = True
        btnEnter.Enabled = True

        ' Set values to their default state
        day = 0
        employee = 0
        lblDay.Text = "Day " & (day + 1)
        employeeTotalUnitsShipped = 0
        overallTotalUnitsShipped = 0

        ' Set focus to the units input
        txtUnitsInput.Focus()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        ' Variable declaration
        Const DaysInWeek As Integer = 7
        Const NumberOfEmployees As Integer = 3


        ' Check that the entry is a valid number between 0.0 and 5000.0
        If Double.TryParse(txtUnitsInput.Text, unitsArray(employee, day)) Then
            If (Convert.ToDouble(txtUnitsInput.Text) > 5000.0 Or Convert.ToDouble(txtUnitsInput.Text) < 0.0) Then 'Displays error message
                MessageBox.Show("The entered units is not a valid range. Please enter a whole number between 0 & 5000 and try again.")
                txtUnitsInput.SelectAll()
                txtUnitsInput.Focus()

            ElseIf Double.TryParse(txtUnitsInput.Text, unitsArray(employee, day)) Then

                ' Output the new units shipped value
                textboxArray(employee).Text &= unitsArray(employee, day) & vbCrLf

                ' The entry is valid... increment the day
                day += 1
                lblDay.Text = "Day " & (day + 1)

                txtUnitsInput.Clear()

                ' If we have reached Day 7, then calculate the average units shipped for that employee
                If day = DaysInWeek Then

                    ' Reset the employee total units shipped
                    employeeTotalUnitsShipped = 0

                    ' Accumulate the employees total units shipped
                    For dayCounter As Integer = 0 To DaysInWeek - 1
                        employeeTotalUnitsShipped += unitsArray(employee, dayCounter)
                    Next

                    ' Determine and output the average (units total / number of days)
                    employeeAverageUnitsShipped = employeeTotalUnitsShipped / DaysInWeek
                    outputLabelArray(employee).Text = "Average:" & Math.Round(employeeAverageUnitsShipped, 2)

                    ' Increment to the next employee
                    employee += 1

                    ' Reset the day to 0
                    day = 0
                    lblDay.Text = "Day " & (day + 1)

                    ' If we have reached Employee 3, calculate the average
                    If employee = NumberOfEmployees Then

                        ' Gather the total units shipped for the three employees
                        For Each day In unitsArray
                            overallTotalUnitsShipped += day
                        Next

                        ' Determine and output the average (overall total / number of days)
                        overallAverageUnitsShipped = overallTotalUnitsShipped / unitsArray.Length
                        lblOverallAverageOutput.Text = "Average per day: " & Math.Round(overallAverageUnitsShipped, 2)

                        ' Disable the input related controls
                        txtUnitsInput.Enabled = False
                        btnEnter.Enabled = False
                        btnReset.Focus()

                        lblDay.Text = "Done"

                    End If
                End If
            End If

        Else
            ' The entry is not a valid double value..show an error message
            MessageBox.Show("Units must be entered as a whole number.")
            txtUnitsInput.SelectAll()
            txtUnitsInput.Focus()

        End If

    End Sub

#End Region

End Class
